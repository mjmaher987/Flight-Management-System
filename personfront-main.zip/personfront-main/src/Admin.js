
import Navbar from './components/Navbar';
import Search from './components/Search';
import Table from './components/Table';
import AddPerson from './components/AddPerson';

import React, { useEffect, useState } from 'react';

const Admin = () => {
  const [persons, setPersons] = useState([])
  const [curuntPersons, setCuruntPersons] = useState([])
  const [personSelect, setPersonSelect] = useState([])

  const componentDidMount = async () => {
    const response = await fetch("http://172.27.14.16:8000/survey/get_passengers")
    const responseData = await response.json()
    setPersons(responseData)
    setCuruntPersons(responseData)
  } 
  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
  useEffect(() => {
    componentDidMount()
  }, []);

  const filterPerson = (e) => {
    setCuruntPersons(persons.filter((item) => {
      if (item.name.includes(e)) return true;
      if (item.naturalNumber == null) return false;
      if (item.naturalNumber.includes(e)) return true;
      // if (item.phoneNumber.includes(e)) return true;
    }))
  }
  const csrftoken = getCookie('csrftoken');

  const addPerson = async (e) => {
    await fetch("http://172.27.14.16:8000/survey/update_passenger", {
      method: "POST",
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-CSRFToken': csrftoken
      },
      body: JSON.stringify(e)
    })

    componentDidMount()
    console.log(e)
  }

  const select = (e) => {
    setPersonSelect(e)
    console.log(e)
  }

  return (
    <div className="Admin" dir='rtl'>
      <Navbar />
      <Search filterFunc={filterPerson} />
      <AddPerson addPerson={addPerson} select={personSelect} />
      <Table persons={curuntPersons} select={select} />
    </div>
  );
}

export default Admin;
