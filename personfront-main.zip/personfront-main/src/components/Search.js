import { useState } from "react";

const Search = ({filterFunc}) => {
  const [text, setText] = useState()
  
  const onChange = (e) => {
    setText(e)
    filterFunc(e)
  }
  return (
    <div className="container py-3 col-12">
      <form
        onSubmit={onChange}
        className="col-12 col-lg-auto mb-6 mb-lg-0 me-2"
      >
        <input
          type="search"
          className="form-control form-control-dark "
          style={{ textAlign: "center" }}
          placeholder="جست و جو"
          aria-label="Search"
          value={text}
          onChange={(e) => { onChange(e.target.value) }}
        />
      </form>
    </div>
  );
};
export default Search;
