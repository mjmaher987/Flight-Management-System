import * as React from "react";

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-sm navbar-toggleable-sm navbar-light bg-white border-bottom box-shadow mb-2 ">
      <div className="container">
        <a className="navbar-brand" href="/">
          لیست مسافران
        </a>
      </div>
    </nav>
  );
};
export default Navbar;
