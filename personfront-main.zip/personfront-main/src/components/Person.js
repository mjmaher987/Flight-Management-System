const Person = ({ person , select}) => {
    return (
        <tr onClick={(e)=>{select(person)}}>
            <th scope="row">{person.id}</th>
            <td>{person.name}</td>
            <td>{person.passportnumber}</td>
            <td>{person.gender}</td>
          </tr>
    )
}

export default Person