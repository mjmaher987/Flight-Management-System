import { useEffect, useState } from "react";

const AddPerson = ({ addPerson, select }) => {
    const [id, setId] = useState("")
    const [name, setName] = useState("")
    const [passportNumber, setPassportNumber] = useState("")
    const [gender, setGender] = useState("")

    const personModel = () => {
        return { id, name, passportNumber,gender}
    }
    const addPersonFunc = (e) => {
        e.preventDefault()
        addPerson(personModel())
    }
    useEffect(() => {
        setId(select.id)
        setName(select.name)
        setPassportNumber(select.passportnumber)
        setGender(select.gender)
    });
    return (
        <div className="col-sm-12 d-flex justify-content-center">
            <form className="row" onSubmit={addPersonFunc}>
                <div className="col-md-2">
                    <input type="text" className="form-control" id="inputEmail4" placeholder="کد مسافر" value={id} onChange={(e) => {
                        setId(e.target.value)
                        select.passengerId = e.target.value
                    }} />
                </div>
                <div className="col-md-4">
                    <input type="text" className="form-control" id="inputPassword4" placeholder="نام و نام خانوادگی" value={name} onChange={(e) => {
                        setName(e.target.value)
                        select.name = e.target.value
                    }} />
                </div>
                <div className="col-md-1" >
                    <input type="text" className="form-control" id="inputPassword4" placeholder="جنسیت" value={gender} onChange={(e) => {
                        setGender(e.target.value)
                        select.gender = e.target.value
                    }} />
                </div>
                <div className="col-md-3" >
                    <input type="text" className="form-control" id="inputPassword4" placeholder="شماره پاسپورت" value={passportNumber} onChange={(e) => {
                        setPassportNumber(e.target.value)
                        select.passportnumber = e.target.value
                    }} />
                </div>
                <div className="col-1">
                    <button type="submit" className="btn btn-primary">ثبت</button>
                </div>
                <div className="col-1">
                    <button type="submit" className="btn btn-primary">حذف</button>
                </div>
            </form>
        </div>
    );
}

export default AddPerson