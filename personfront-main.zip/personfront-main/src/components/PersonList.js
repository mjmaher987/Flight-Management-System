import Person from "./Person"

const PersonList = ({ persons }) => {
    return (
        <>
            {persons.map((person) => {
                return <Person key={person.id} person={person} />

            })}
        </>
    )
}

export default PersonList