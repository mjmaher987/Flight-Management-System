import * as React from "react";
import Person from "./Person";

const Table = ({ persons, select }) => {
  return (
    <div className="bd-example p-4 rounded">
      <table className="table table-striped">
        <thead>
          <tr>
            <th scope="col">کد مسافر</th>
            <th scope="col">نام و نام خانوادگی</th>
            <th scope="col">شماره پاسپورت</th>
            <th scope="col">جنسیت</th>
          </tr>
        </thead>
        <tbody>
          {persons.map((person) => {
            return <Person key={person.id} person={person} select={select} />
          })}

        </tbody>
      </table>
    </div>
  );
};
export default Table;
